"""
Text processing and preprocessing utilities
"""

import re
import string
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.corpus import stopwords


class TextProcessor:
    """Handles text preprocessing and cleaning"""

    def __init__(self):
        try:
            self.stop_words = set(stopwords.words('english'))
        except:
            self.stop_words = set()

    def clean_text(self, text):
        """
        Clean and normalize text
        
        Args:
            text (str): Raw text
            
        Returns:
            str: Cleaned text
        """
        if not isinstance(text, str):
            return ""

        # Remove URLs
        text = re.sub(r'http\S+|www\S+|https\S+', '', text, flags=re.MULTILINE)

        # Remove email addresses
        text = re.sub(r'\S+@\S+', '', text)

        # Remove special characters and extra whitespace
        text = re.sub(r'\s+', ' ', text)

        # Remove extra punctuation
        text = re.sub(r'[^\w\s.]', '', text)

        return text.strip()

    def tokenize_sentences(self, text):
        """Split text into sentences"""
        try:
            return sent_tokenize(text)
        except:
            return text.split('.')

    def tokenize_words(self, text):
        """Split text into words"""
        try:
            return word_tokenize(text)
        except:
            return text.lower().split()

    def remove_stopwords(self, words):
        """Remove stopwords from word list"""
        return [word for word in words if word.lower() not in self.stop_words]

    def get_text_stats(self, text):
        """Get text statistics"""
        sentences = self.tokenize_sentences(text)
        words = self.tokenize_words(text)
        unique_words = set(w.lower() for w in words if w.isalpha())

        return {
            'char_count': len(text),
            'word_count': len(words),
            'sentence_count': len(sentences),
            'unique_words': len(unique_words),
            'avg_word_length': len(text) / len(words) if words else 0,
            'vocabulary_richness': len(unique_words) / len(words) if words else 0
        }

    def validate_text(self, text, min_length=10, max_length=50000):
        """Validate text input"""
        if not isinstance(text, str):
            raise ValueError("Input must be a string")

        if len(text) < min_length:
            raise ValueError(f"Text must be at least {min_length} characters")

        if len(text) > max_length:
            raise ValueError(f"Text must not exceed {max_length} characters")

        if not text.strip():
            raise ValueError("Text cannot be empty or whitespace only")

        return True
