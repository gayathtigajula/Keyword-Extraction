"""
Streamlit Web Interface for ML-based Keyword Extraction
Advanced NLP with spaCy - Best Output
"""

import streamlit as st
import sys, os, json, time
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.ml_based import MLBasedExtractor
from src.text_processor import TextProcessor

# Page config
st.set_page_config(page_title="Keyword Extraction", page_icon="🔍", layout="wide")

@st.cache_resource
def init_extractors():
    return MLBasedExtractor(), TextProcessor()

# Styling
st.markdown("""<style>
.metric-card { background: linear-gradient(135deg, #667eea, #764ba2); color: white; padding: 20px; border-radius: 10px; }
.keyword-item { padding: 10px; margin: 5px 0; border-radius: 5px; background: #f0f2f6; border-left: 4px solid #667eea; }
</style>""", unsafe_allow_html=True)

st.title("🔍 NLP Keyword Extraction")
st.markdown("### Advanced Machine Learning with spaCy - Best Output")

# Sidebar
with st.sidebar:
    st.header("⚙️ Settings")
    max_kw = st.slider("Max Keywords:", 5, 50, 15)
    conf_thresh = st.slider("Confidence Threshold:", 0.0, 1.0, 0.25, 0.05)

# Tabs
tab1, tab2, tab3 = st.tabs(["🚀 Extract", "📊 Analyze", "ℹ️ About"])

with tab1:
    text_input = st.text_area("Paste article text:", height=250, placeholder="Enter text for keyword extraction...")
    
    col1, col2 = st.columns([1, 1])
    extract_btn = col1.button("🔍 Extract Keywords", use_container_width=True, type="primary")
    clear_btn = col2.button("🧹 Clear", use_container_width=True)
    
    if clear_btn:
        st.rerun()
    
    if extract_btn and text_input.strip():
        try:
            ml_ex, text_proc = init_extractors()
            
            text_proc.validate_text(text_input)
            clean_text = text_proc.clean_text(text_input)
            
            progress = st.progress(0)
            status = st.empty()
            
            start = time.time()
            
            status.text("🔄 Advanced NLP Extraction (spaCy)...")
            progress.progress(50)
            
            final_kw = ml_ex.extract(clean_text, max_kw)
            
            status.text("🔄 Filtering & scoring...")
            progress.progress(100)
            
            final_kw = [(kw, s) for kw, s in final_kw if s >= conf_thresh]
            final_kw = final_kw[:max_kw]
            
            elapsed = time.time() - start
            progress.empty()
            status.empty()
            
            st.success("✅ Extraction complete!")
            
            col1, col2, col3, col4 = st.columns(4)
            col1.metric("Method", "NLP (spaCy)")
            col2.metric("Keywords", len(final_kw))
            col3.metric("Avg Confidence", f"{(sum(s for _,s in final_kw)/len(final_kw) if final_kw else 0):.1%}")
            col4.metric("Time", f"{elapsed:.2f}s")
            
            st.divider()
            st.subheader(f"📌 Keywords ({len(final_kw)})")
            
            if final_kw:
                for i, (kw, score) in enumerate(final_kw, 1):
                    col1, col2, col3 = st.columns([0.5, 2.5, 1.5])
                    col1.write(f"**{i}**")
                    col2.write(f"`{kw}`")
                    col3.progress(min(score, 1.0))
                
                st.divider()
                col1, col2 = st.columns(2)
                
                json_str = json.dumps([{"rank": i, "keyword": kw, "score": f"{s:.4f}"} 
                                       for i, (kw, s) in enumerate(final_kw, 1)], indent=2)
                col1.download_button("📥 JSON", json_str, 
                                    f"keywords_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json", 
                                    use_container_width=True)
                
                csv_str = "Rank,Keyword,Score\n" + "\n".join([f"{i},\"{kw}\",{s:.4f}" 
                                                               for i, (kw, s) in enumerate(final_kw, 1)])
                col2.download_button("📥 CSV", csv_str,
                                    f"keywords_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                                    use_container_width=True)
            else:
                st.info("No keywords found. Try lowering the confidence threshold.")
        
        except Exception as e:
            st.error(f"❌ Error: {str(e)}")

with tab2:
    if text_input.strip():
        try:
            _, text_proc = init_extractors()
            stats = text_proc.get_text_stats(text_input)
            
            col1, col2, col3 = st.columns(3)
            col1.metric("Characters", f"{stats['char_count']:,}")
            col2.metric("Words", f"{stats['word_count']:,}")
            col3.metric("Sentences", f"{stats['sentence_count']}")
            
            col1, col2, col3 = st.columns(3)
            col1.metric("Avg Word Length", f"{stats['avg_word_length']:.1f}")
            col2.metric("Unique Words", f"{stats['unique_words']:,}")
            col3.metric("Vocabulary", f"{stats['vocabulary_richness']:.1%}")
            
        except Exception as e:
            st.error(f"Error: {str(e)}")
    else:
        st.info("👈 Enter text to analyze")

with tab3:
    st.markdown("""
    ## 🎯 Advanced NLP Keyword Extraction
    
    ### How It Works
    
    This system uses **advanced Machine Learning** with **spaCy NLP** to extract high-quality keywords:
    
    #### 🔬 Three-Method Approach:
    
    1. **Named Entity Recognition (50%)**
       - Identifies important entities (people, organizations, places, products)
       - High confidence scoring (0.80-0.95)
       - Filters by entity type
    
    2. **Noun Chunk Extraction (30%)**
       - Extracts 2-word phrases only
       - Removes connectors and articles
       - Quality validation
    
    3. **TF-IDF Scoring (20%)**
       - Important single words
       - Semantic relevance
       - Frequency analysis
    
    #### ✨ Quality Filters:
    - Maximum 25 characters per keyword
    - Maximum 2 words per keyword
    - Removes common stopwords
    - Removes phrase patterns
    - Diversity checking
    
    #### 🎯 Perfect For:
    - News articles
    - Research papers
    - Blog posts
    - Technical documentation
    - Social media content
    
    ### Settings
    - **Max Keywords**: Control how many keywords to extract
    - **Confidence Threshold**: Filter out low-confidence results
    
    ### Export
    - Download results as **JSON** or **CSV**
    - Ready for further analysis
    """)

st.divider()
st.caption("🚀 Powered by spaCy NLP | Best ML-based Keyword Extraction")
