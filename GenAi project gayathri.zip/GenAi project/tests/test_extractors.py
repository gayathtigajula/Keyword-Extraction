"""
Unit tests for extraction methods
"""

import unittest
from src.rule_based import RuleBasedExtractor
from src.ml_based import MLBasedExtractor
from src.text_processor import TextProcessor


class TestRuleBasedExtractor(unittest.TestCase):
    """Test rule-based extraction"""

    def setUp(self):
        self.extractor = RuleBasedExtractor()

    def test_extract_returns_list(self):
        """Test that extract returns a list"""
        text = "Artificial intelligence and machine learning are transforming technology."
        result = self.extractor.extract(text)
        self.assertIsInstance(result, list)

    def test_extract_max_keywords(self):
        """Test maximum keywords limit"""
        text = "Technology AI ML neural networks deep learning data science python algorithms."
        result = self.extractor.extract(text, max_keywords=5)
        self.assertLessEqual(len(result), 5)

    def test_extract_score_range(self):
        """Test that scores are between 0 and 1"""
        text = "Data science is important for modern applications."
        result = self.extractor.extract(text)
        for keyword, score in result:
            self.assertGreaterEqual(score, 0)
            self.assertLessEqual(score, 1)

    def test_extract_empty_text(self):
        """Test with empty text"""
        result = self.extractor.extract("")
        self.assertIsInstance(result, list)


class TestMLBasedExtractor(unittest.TestCase):
    """Test ML-based extraction"""

    def setUp(self):
        self.extractor = MLBasedExtractor()

    def test_extract_returns_list(self):
        """Test that extract returns a list"""
        text = "Apple Inc. is a technology company based in California."
        result = self.extractor.extract(text)
        self.assertIsInstance(result, list)

    def test_extract_max_keywords(self):
        """Test maximum keywords limit"""
        text = "IBM, Google, and Microsoft are tech giants in California and Washington."
        result = self.extractor.extract(text, max_keywords=3)
        self.assertLessEqual(len(result), 3)

    def test_extract_named_entities(self):
        """Test named entity extraction"""
        text = "Steve Jobs founded Apple in California."
        result = self.extractor.extract(text)
        # Should extract Steve Jobs, Apple, California
        self.assertGreater(len(result), 0)


class TestTextProcessor(unittest.TestCase):
    """Test text processing utilities"""

    def setUp(self):
        self.processor = TextProcessor()

    def test_clean_text_removes_urls(self):
        """Test URL removal"""
        text = "Visit https://www.example.com for more info"
        cleaned = self.processor.clean_text(text)
        self.assertNotIn("https://", cleaned)

    def test_clean_text_removes_emails(self):
        """Test email removal"""
        text = "Contact us at test@example.com"
        cleaned = self.processor.clean_text(text)
        self.assertNotIn("@", cleaned)

    def test_tokenize_sentences(self):
        """Test sentence tokenization"""
        text = "First sentence. Second sentence. Third sentence."
        sentences = self.processor.tokenize_sentences(text)
        self.assertGreaterEqual(len(sentences), 3)

    def test_get_text_stats(self):
        """Test text statistics"""
        text = "The quick brown fox jumps over the lazy dog."
        stats = self.processor.get_text_stats(text)
        self.assertIn('word_count', stats)
        self.assertIn('sentence_count', stats)
        self.assertGreater(stats['word_count'], 0)

    def test_validate_text_valid(self):
        """Test text validation with valid input"""
        text = "This is a valid text with sufficient length."
        self.assertTrue(self.processor.validate_text(text))

    def test_validate_text_too_short(self):
        """Test text validation with short input"""
        with self.assertRaises(ValueError):
            self.processor.validate_text("short")

    def test_validate_text_empty(self):
        """Test text validation with empty input"""
        with self.assertRaises(ValueError):
            self.processor.validate_text("")

    def test_validate_text_too_long(self):
        """Test text validation with very long input"""
        long_text = "word " * 60000
        with self.assertRaises(ValueError):
            self.processor.validate_text(long_text)


if __name__ == '__main__':
    unittest.main()
