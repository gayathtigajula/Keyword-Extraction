"""
Unit tests for API endpoints
"""

import unittest
import json
from src.app import app


class TestAPIEndpoints(unittest.TestCase):
    """Test API endpoints"""

    def setUp(self):
        """Set up test client"""
        self.app = app
        self.client = app.test_client()
        self.app.config['TESTING'] = True

    def test_health_check(self):
        """Test health check endpoint"""
        response = self.client.get('/api/health')
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertEqual(data['status'], 'healthy')

    def test_extract_rule_based(self):
        """Test rule-based extraction endpoint"""
        payload = {
            'text': 'Artificial intelligence and machine learning are transforming technology.'
        }
        response = self.client.post(
            '/api/extract/rule-based',
            data=json.dumps(payload),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertEqual(data['status'], 'success')
        self.assertEqual(data['method'], 'rule-based')
        self.assertIn('keywords', data)

    def test_extract_ml_based(self):
        """Test ML-based extraction endpoint"""
        payload = {
            'text': 'Apple Inc. is a technology company based in California.'
        }
        response = self.client.post(
            '/api/extract/ml-based',
            data=json.dumps(payload),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertEqual(data['status'], 'success')
        self.assertEqual(data['method'], 'ml-based')

    def test_extract_combined(self):
        """Test combined extraction endpoint"""
        payload = {
            'text': 'Data science and machine learning are revolutionizing data analysis.'
        }
        response = self.client.post(
            '/api/extract/combined',
            data=json.dumps(payload),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertEqual(data['status'], 'success')
        self.assertEqual(data['method'], 'combined')

    def test_extract_missing_text(self):
        """Test extraction with missing text"""
        payload = {}
        response = self.client.post(
            '/api/extract/rule-based',
            data=json.dumps(payload),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, 400)

    def test_analyze_endpoint(self):
        """Test text analysis endpoint"""
        payload = {
            'text': 'The quick brown fox jumps over the lazy dog.'
        }
        response = self.client.post(
            '/api/analyze',
            data=json.dumps(payload),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertIn('statistics', data)

    def test_about_endpoint(self):
        """Test about endpoint"""
        response = self.client.get('/api/health')
        self.assertEqual(response.status_code, 200)

    def test_404_endpoint(self):
        """Test 404 handling"""
        response = self.client.get('/api/nonexistent')
        self.assertEqual(response.status_code, 404)


if __name__ == '__main__':
    unittest.main()
