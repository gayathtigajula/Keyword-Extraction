"""
Advanced Machine Learning-based Keyword Extraction with NLP
Using spaCy for semantic understanding
"""

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
import spacy


class MLBasedExtractor:
    """Advanced ML-based keyword extraction"""

    def __init__(self):
        try:
            self.nlp = spacy.load('en_core_web_sm')
        except OSError:
            self.nlp = None

    def extract(self, text, max_keywords=15):
        """
        Extract keywords using NLP methods with optimized ranking
        
        Args:
            text (str): Input text
            max_keywords (int): Maximum keywords to extract
            
        Returns:
            list: List of (keyword, score) tuples
        """
        if not text or len(text.strip()) < 10:
            return []
        
        keywords = {}

        # Method 1: Named Entity Recognition (50% weight) - MOST IMPORTANT
        ner_keywords = self._extract_named_entities(text)
        for kw, score in ner_keywords:
            keywords[kw] = keywords.get(kw, 0) + score * 0.50

        # Method 2: Important nouns (35% weight)
        noun_keywords = self._extract_nouns(text)
        for kw, score in noun_keywords:
            keywords[kw] = keywords.get(kw, 0) + score * 0.35

        # Method 3: TF-IDF (15% weight)
        tfidf_keywords = self._extract_tfidf(text)
        for kw, score in tfidf_keywords:
            keywords[kw] = keywords.get(kw, 0) + score * 0.15

        # Sort and filter - RELAXED FILTERING
        sorted_kw = sorted(keywords.items(), key=lambda x: x[1], reverse=True)
        
        # Filter: keep only meaningful keywords
        filtered_kw = []
        for kw, score in sorted_kw:
            # Must be at least 3 characters
            if len(kw) < 3:
                continue
            # Max 2 words
            if len(kw.split()) > 2:
                continue
            # Skip pure stop words
            if kw.lower() in {'the', 'a', 'an', 'and', 'or', 'but', 'is', 'are', 'was', 'were'}:
                continue
            filtered_kw.append((kw, score))
        
        return filtered_kw[:max_keywords]

    def _extract_named_entities(self, text):
        """Extract named entities"""
        try:
            if not self.nlp:
                return []

            doc = self.nlp(text)
            entities = []
            
            entity_scores = {
                'PERSON': 0.95,
                'ORG': 0.95,
                'GPE': 0.90,
                'PRODUCT': 0.90,
                'EVENT': 0.85,
                'FAC': 0.85,
                'LAW': 0.85,
                'WORK_OF_ART': 0.85,
                'LANGUAGE': 0.80
            }

            for ent in doc.ents:
                if ent.label_ in entity_scores:
                    entity_text = ent.text.lower().strip()
                    if len(entity_text) >= 3:
                        score = entity_scores[ent.label_]
                        entities.append((entity_text, score))

            return entities
        except Exception:
            return []

    def _extract_nouns(self, text):
        """Extract important nouns and noun chunks with better prioritization"""
        try:
            if not self.nlp:
                return []

            doc = self.nlp(text)
            nouns = {}
            
            # Extract noun chunks FIRST (weighted higher)
            for chunk in doc.noun_chunks:
                chunk_text = chunk.text.lower().strip()
                word_count = len(chunk_text.split())
                
                if 1 <= word_count <= 2 and len(chunk_text) <= 25:
                    # Skip if it's pure pronouns or articles
                    if not self._is_article_or_pronoun(chunk_text):
                        nouns[chunk_text] = nouns.get(chunk_text, 0) + 3  # Higher weight for chunks
            
            # Extract single nouns (LOWER weight than chunks)
            noun_tokens = {}
            for token in doc:
                if token.pos_ in ['NOUN', 'PROPN'] and not token.is_stop:
                    word = token.text.lower().strip()
                    if len(word) >= 3:
                        noun_tokens[word] = noun_tokens.get(word, 0) + 1
            
            # Add noun tokens with lower weight
            for word, count in noun_tokens.items():
                nouns[word] = nouns.get(word, 0) + count
            
            # Normalize scores
            if nouns:
                max_count = max(nouns.values())
                return [(kw, min(count / max_count, 1.0)) for kw, count in nouns.items()]
            
            return []
        except Exception:
            return []

    def _is_article_or_pronoun(self, text):
        """Check if text is purely article or pronoun"""
        articles_pronouns = {
            'the', 'a', 'an', 'this', 'that', 'these', 'those',
            'my', 'your', 'his', 'her', 'its', 'our', 'their',
            'i', 'you', 'he', 'she', 'it', 'we', 'they'
        }
        return text.lower() in articles_pronouns

    def _extract_tfidf(self, text):
        """Extract TF-IDF keywords with better scoring"""
        try:
            vectorizer = TfidfVectorizer(
                max_features=60,
                stop_words='english',
                ngram_range=(1, 2),
                min_df=1,
                max_df=0.95,
                lowercase=True,
                token_pattern=r'(?u)\b[a-z]{3,}\b'  # Min 3 characters
            )
            
            tfidf_matrix = vectorizer.fit_transform([text])
            feature_names = vectorizer.get_feature_names_out()
            scores = tfidf_matrix.toarray()[0]
            
            keywords = []
            for idx, score in enumerate(scores):
                if score > 0.005:  # Lower threshold for more keywords
                    keyword = feature_names[idx]
                    if len(keyword) >= 3:
                        keywords.append((keyword, float(score)))
            
            return sorted(keywords, key=lambda x: x[1], reverse=True)[:40]
        except Exception:
            return []
