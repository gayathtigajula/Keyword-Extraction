"""
Configuration settings for the Keyword Extraction System
"""

import os
from dotenv import load_dotenv

load_dotenv()

# Flask Configuration
FLASK_ENV = os.getenv('FLASK_ENV', 'development')
DEBUG = FLASK_ENV == 'development'
SECRET_KEY = os.getenv('SECRET_KEY', 'dev-secret-key-change-in-production')

# Server Configuration
HOST = os.getenv('HOST', '0.0.0.0')
PORT = int(os.getenv('PORT', 5000))

# Keyword Extraction Configuration
MAX_KEYWORDS = int(os.getenv('MAX_KEYWORDS', 15))
MIN_KEYWORD_LENGTH = int(os.getenv('MIN_KEYWORD_LENGTH', 2))
CONFIDENCE_THRESHOLD = float(os.getenv('CONFIDENCE_THRESHOLD', 0.3))

# Model Configuration
SPACY_MODEL = 'en_core_web_sm'
USE_GPU = os.getenv('USE_GPU', 'false').lower() == 'true'

# Processing Configuration
BATCH_SIZE = int(os.getenv('BATCH_SIZE', 32))
MAX_TEXT_LENGTH = int(os.getenv('MAX_TEXT_LENGTH', 50000))

# Logging Configuration
LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
LOG_FILE = os.getenv('LOG_FILE', 'logs/app.log')

# API Configuration
API_VERSION = 'v1'
API_TIMEOUT = int(os.getenv('API_TIMEOUT', 30))
RATE_LIMIT = os.getenv('RATE_LIMIT', '100/hour')

# Method Weights (for combined extraction)
RULE_BASED_WEIGHT = float(os.getenv('RULE_BASED_WEIGHT', 0.4))
ML_BASED_WEIGHT = float(os.getenv('ML_BASED_WEIGHT', 0.6))
